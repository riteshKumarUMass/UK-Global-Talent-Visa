V53 - EVIDENCE RENUMBERED BY CRITERION
INTERNAL GUIDE - DO NOT UPLOAD

The evidence sequence is now contiguous by criterion so related documents appear together in filename order.

EVIDENCE ALLOCATION AND EXACT FILENAMES

Leading Talent Recognition
- E1_Leading_Talent_TCAP_and_IBM_Recognition.pdf
- E2_Leading_Talent_ProtoNER_Research_to_Granted_Patent.pdf
- E3_Leading_Talent_Independent_External_Recognition.pdf

Innovation as an employee in a new digital field or concept
- E4_Innovation_Four_Filed_US_Patent_Applications.pdf
- E5_Innovation_CUGA_Open_Source_Agentic_AI.pdf

Research published or endorsed by an expert
- E6_Research_FLOW_BENCH_and_FLOW_GEN.pdf
- E7_Research_Sustained_Publications_and_Scholarly_Impact.pdf

Supporting personal factor
- E8_Supporting_Compensation_and_Career_Progression.pdf

CLEAN UPLOAD ORDER
1. CV
2. Personal statement / application-form narrative, where requested
3. Three signed recommendation letters and recommender credential proof
4. E1, E2, E3 - Leading Talent Recognition
5. E4, E5 - Innovation
6. E6, E7 - Published research
7. E8 - Supporting personal factor

FINAL EXECUTION CHECKS
1. Obtain the third recommendation letter from an established expert who has known Ritesh's work for at least 12 months.
2. Ensure all three letters are personally reviewed, dated, signed, on appropriate letterhead, and include professional email, telephone and organisation address.
3. Attach actual recommender CVs or other acceptable independent credential proof where available.
4. Keep the IBM title explanation consistent: functional role "AI Research Software Engineer"; IBM HR record "Software Developer".
5. Keep all web-source URLs visible and legible.
6. Review IBM Think IP filing records and obtain any necessary permission before disclosure.
7. Do not upload this guide, the evidence map, or the pending-third-recommender folder.
