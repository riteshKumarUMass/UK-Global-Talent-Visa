RECOMMENDATION LETTERS - FROZEN

The contents of the Vatche Isahagian and Kishor Saitwal recommendation letters were not edited during V53 evidence renumbering.

- Vatche: latest approved working draft from V51.
- Kishor: latest executive-voice working draft from V39.

Before submission, each recommender must personally review the final text, insert the date and professional contact details, place the letter on appropriate organisation letterhead, and sign it. Add the confirmed third recommendation letter separately.
