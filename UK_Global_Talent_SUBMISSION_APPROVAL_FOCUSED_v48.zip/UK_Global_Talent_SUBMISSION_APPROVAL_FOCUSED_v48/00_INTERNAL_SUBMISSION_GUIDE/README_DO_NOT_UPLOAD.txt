V46 SUBMISSION GUIDE - DO NOT UPLOAD THIS FILE AS EVIDENCE

CURRENT STRUCTURE
Leading Talent Recognition: E1 + E2 + E8
Additional Criterion - Innovation as an employee in a new digital field or concept: E3 + E4
Additional Criterion - Research published or endorsed by an expert: E5 + E6
Supporting personal factor: E7

BLOCKERS BEFORE SUBMISSION
1. E3 IS NOT READY. Do not submit until the four IBM filing/disclosure records naming Ritesh are inserted.
2. All three recommendation letters must be personally reviewed, dated, signed and placed on appropriate organisation letterhead/logo with professional contact details.
3. Archan Misra is currently the third-recommender draft. If he is unavailable, replace him with a qualified recommender who has known Ritesh's work for at least 12 months before submission.
4. Confirm the IBM role-title presentation: the CV uses the research-facing title "AI Research Software Engineer" while the 2025 IBM HR salary verification records the position title "Software Developer". Keep both accurate and, if needed, explain the distinction rather than leaving an apparent inconsistency.

FORMATTING / COMPLIANCE CHECK
- CV is A4 and 2 pages.
- Recommendation-letter drafts are now A4. Final letters may be up to 3 A4 sides.
- Maximum 10 evidence documents; current planned set is 8 including E3 and supplementary E7.
- At least 2 documents for leading-talent recognition and 2 documents for each of two additional criteria.
- Each evidence document is at most 3 A4 pages.
- Do not use the same evidence document for more than one criterion.
- Web evidence should appear as a page/screenshot with the hyperlink visible or stated on the evidence page.

E8 / E6 SEPARATION
- E8 exclusively carries AI Paper Reading Club and NewMind third-party attention for Leading Talent Recognition.
- E6 is research-only: recent research output, Google Scholar impact, trajectory-memory research, with older publications used only to show continuity.

UPLOAD ORDER
1. CV
2. Three signed recommendation letters + recommender credentials
3. Leading Talent: E1, E2, E8
4. Innovation: E3 (when completed), E4
5. Research: E5, E6
6. E7 only as supplementary personal-factor evidence if desired

Do not upload this guide, build files, historical versions, raw screenshots or unsigned draft letters.
